import React from "react";
import {BrowserRouter as Router,Routes,Route} from "react-router-dom";
import UserState from "./context/users/UserState";
import Home from "./components/home"
import Login from "./components/login";
import SignUp from "./components/SignUp";
import Navbar from "./components/Navbar";
import Createpost from "./components/Createpost";
import Footer from "./components/footer";
import Profile from "./components/profile";


function App() {
  return (
    <div>
      
        <UserState>
            <Router>
                <Navbar></Navbar>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signUp" element={<SignUp />} />
                    <Route path="/createPost" element={<Createpost />} />
                    <Route path="/profile" element={<Profile />}></Route>

                </Routes>
                <Footer></Footer>
            </Router>
        </UserState>

    </div>
  );
}

export default App;
