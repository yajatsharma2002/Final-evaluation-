import React, { useState } from "react";
import userContext from "./userContext";

const UserState = (props) => {

    const [user, setUser] = useState("");
    const [allUsers,setAllUsers] = useState([]);
    const [userId,setUserId] = useState("");
    const postsinitial=[];
    const [posts,setPosts] =useState([]);
    const [comments,setComments] = useState([]);

    // fetch the current user
    const getUser = async () => {

        // console.log(localStorage.getItem("token"));
        const response = await fetch("http://localhost:5000/users/getUser", {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Authorization': 'Bearer '+(localStorage.getItem("token")), 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        // console.log(response);
        const json = await response.json();
        // console.log(json);
        setUser(json.name);
        setUserId(json._id);
        // console.log(user);
        
        // const name = "hello";
        // setUser(name);
    }

    const getAllUsers=async()=>{
        const response = await fetch("http://localhost:5000/users/getAllUsers", {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
        });
        const json = await response.json();
        // console.log(json);
        setAllUsers(json);
    }



    // creatind post state here also

    const getAllPost=async ()=>{
        // console.log("i will be getting all the posts from data base");
        const response = await fetch("http://localhost:5000/posts/getAllPosts", {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
        });
        const json = await response.json();
        // console.log(json);
        setPosts(json);
        // console.log(json);
        
    }

    const addPost=async(content)=>{
        const response = await fetch("http://localhost:5000/posts/create", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Authorization': 'Bearer ' + (localStorage.getItem("token")),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ content})
        });
        const json = await response.json();
        // console.log(json);
        let post=json;
        setPosts(posts.concat(post));
        // console.log(posts);
    }

    const deletePost=async(id)=>{

        const response = await fetch(`http://localhost:5000/posts/delete/${id}`, {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Authorization': 'Bearer ' + (localStorage.getItem("token")),
                'Content-Type': 'application/json'
            }
        });
        const json = await response.json();
        console.log(json);
        const newPosts=posts.filter((post)=>{ return post._id!==id});
        setPosts(newPosts);
        // let post=json;
        // setPosts(posts.concat(post));

    }



    // all comments date would be here

    const addComment=async(content,postId)=>{
        const response = await fetch("http://localhost:5000/comments/create", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Authorization': 'Bearer ' + (localStorage.getItem("token")),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ content, postId})
        });
        const json = await response.json();
        // console.log(json);

        // here in json we have the post in which updation has been done 
        for(var i=0;i<posts.length;i++){
            if(posts[i]._id == json._id){
                // console.log("post found succesfully");
                posts[i] = json;
            }
        }
        setPosts(posts);


        // let post=json;
        // setPosts(posts.concat(post));
        getAllPost();
        // console.log(posts);
    }

    const getAllComments=async ()=>{
        // console.log("i will be getting all the posts from data base");
        const response = await fetch("http://localhost:5000/comments/allComments", {
            method: 'GET',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
        });
        const json = await response.json();
        // console.log(json);
        setComments(json);
        // console.log(json);
        
    }

    const destroy=async(id)=>{
        console.log("destroy is being called");
        console.log(id);
        const response = await fetch(`http://localhost:5000/comments/destroy/${id}`, {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Authorization': 'Bearer ' + (localStorage.getItem("token")),
                'Content-Type': 'application/json'
            }
        });
        const json = await response.json();
        
        // console.log(json);
        const newPosts=posts.filter((post)=>{ return post._id!==id});
        setPosts(newPosts);
        getAllPost();
    }




    return (
        <userContext.Provider value={{ user, getUser ,addPost,getAllPost,posts,userId,deletePost,getAllUsers,allUsers,addComment,comments,getAllComments,destroy}}>
            {props.children}
        </userContext.Provider>
    )

}

export default UserState;