import React, { useContext, useEffect } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import userContext from "../context/users/userContext"

const Navbar = () => {
    const Navigate = useNavigate();
    const location = useLocation();
    const context = useContext(userContext);
    const { user, getUser } = context;
    
    useEffect(() => {
        if (localStorage.getItem("token")) {
            // console.log("currently Signed In ");
            getUser();

            // console.log(user);
        }
        else {
            // console.log("currently Not Signed In ");
            Navigate("/login");
        }
    }, [])

    const handleLogout = () => {
        localStorage.removeItem("token");
        Navigate("/")
    }
    return (
        <div>
            <div>

                <div className="container">
                    <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">


                        <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                            <h1>Mediap</h1>
                        </ul>

                        {!localStorage.getItem("token") ? <div className="col-md-3 text-end">
                            <Link to="/login" role="button" className={`btn mx-2 ${location.pathname === "/login" ? "btn-primary" : "btn-outline-primary"} `}>Login</Link>
                            <Link to="/signUp" role="button" className={`btn mx-2 ${location.pathname === "/signup" ? "btn-primary" : "btn-outline-primary"} `}>Sign-up</Link>
                        </div> :
                            <div>
                                {/* {getUser} */}

                                {/* <span className="mx-2">{user.name}</span> */}
                                <Link to="/" role="button" className="btn btn-success mx-2">{user}</Link>
                                <button className="btn btn-primary" onClick={handleLogout}>Sign Out</button>
                            </div>
                        }


                    </header>
                </div>

            </div>
        </div>
    )
}

export default Navbar
