import React,{useContext,useEffect} from 'react'
import userContext from "../context/users/userContext";

const Comments = (props) => {

    console.log(props.comment);
    const context = useContext(userContext);
    const {getUser,getAllPost,getAllComments, destroy} = context;

    useEffect(() => {

        // console.log("hello and welcome "+user);
        // console.log(posts);
        if (localStorage.getItem("token")) {
            getUser();
            getAllPost();
            getAllComments();
            // setCommentData(comments);
            // only those of props.post.comments

        }
        else {
            // console.log("currently Not Signed In ");
            // Navigate("/");
            // getAllPost();
        }
    }, [])
    
    

    const handleClick=async(e)=>{
        e.preventDefault();
        destroy(props.comment);
        
    }

  return (
    <div>
     { props.comment}  <button onClick={handleClick}> del  </button>
    </div>
  )
}

export default Comments
