import React, { useContext, useEffect } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import userContext from "../context/users/userContext"
import Createpost from './Createpost'
import Post from "./post";
import "./home.css"

const Home = () => {
    const Navigate = useNavigate();
    const location = useLocation();
    const context = useContext(userContext);
    const { user, getUser, getAllPost, posts,allUsers,getAllUsers } = context;


    let temp = "";
    useEffect(() => {
        getAllPost();
        // console.log("hello and welcome "+user);
        // console.log(posts);
        if (localStorage.getItem("token")) {
            // console.log("currently Signed In ");
            // getAllPost();

            getUser();
            getAllUsers();
            getAllPost();

        }
        else {
            // console.log("currently Not Signed In ");
            Navigate("/");
            // getAllPost();
            // console.log("currently the user is noth there ");
        }
    }, [])

    if (localStorage.getItem("token")) {
        temp = <Createpost></Createpost>

    }

    // const profilepage= async(e)=>{
    //     e.preventDefault();
    //     Navigate("/profile")
    //     console.log("going to persons profile page");
    // }


    return (

        <div className='home-container'>

            <div className='feed-posts'>
                <div className='container'>
                    {temp}
                    <div class="album py-5 bg-light">
                        <div class="container">
                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" id="content" >
                                {posts.slice(0).reverse().map((post) => {
                                    // const postUser = findPostUser(post);
                                    return (
                                        <>
                                            <Post post={post}></Post>
                                        </>

                                    )

                                })}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div className='user-friends'>
                <h2 style={{marginBottom:30}}>Friends</h2>
                {allUsers.map((user)=>{
                    return (
                        <div onClick={()=>{
                            Navigate("/profile",{state:{user:user}})
                            console.log("going to persons profile page");
                        }} className='box'>
                            <li>{user.name}</li> 
                        </div>
                    )
                })}

            </div>

        </div>
    )
}

export default Home;
