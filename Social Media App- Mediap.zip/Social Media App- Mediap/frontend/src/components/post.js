import React, { useState, useEffect, useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import userContext from "../context/users/userContext";
import Comments from './comments';

const Post = (props) => {

    // console.log(props.post.comments);

    const { post } = props;


    const [content, setContent] = useState({ content: "" })

    const [commentdata, setCommentData] = useState([]);


    const context = useContext(userContext);
    const { userId, getUser, deletePost, addComment, getAllPost, posts, comments, getAllComments ,destroy} = context;
    const Navigate = useNavigate();

    useEffect(() => {

        // console.log("hello and welcome "+user);
        // console.log(posts);
        if (localStorage.getItem("token")) {
            getUser();
            getAllPost();
            getAllComments();
            // setCommentData(comments);
            // only those of props.post.comments

        }
        else {
            // console.log("currently Not Signed In ");
            Navigate("/");
            // getAllPost();
        }
    }, [])

    const handleClick = async (e) => {
        e.preventDefault();
        console.log("now i will be deleting the post");
        deletePost(post._id)
    }

    // let comments = [];

    const createComment = async (e) => {
        e.preventDefault();
        addComment(content.content, post._id);
        console.log(props.post);
        console.log(commentdata);

        setContent({ content: "" })

    }

    const handleChange = (e) => {
        setContent({ ...content, [e.target.name]: e.target.value })
    }

    



    // console.log(post);

    let temp = "";
    let commentForm = "";
    let deleteComment="";



    if (localStorage.getItem("token")) {
        commentForm =
            <form onSubmit={createComment} class="row g-1">
                <div class="col-auto">
                    <input type="text" name="content" placeholder="Add Comment..." required class="form-control" value={content.content} onChange={handleChange} />
                    {/* <input type="hidden" name="post" value="<%=post._id%>" /> */}
                </div>
                <div class="col-auto">
                    <input type="submit" value="Go" class="btn btn-dark mb-3" />
                </div>
            </form>
    }


    if (localStorage.getItem("token") && post.user.toString() == userId) {
        temp = <button type="button" class="btn btn-outline-dark btn-sm btn-block" onClick={handleClick}>Delete Post</button>
    }

    return (
        <div>
            <div class="col">
                <div class="card ">
                    <div class="card-body">

                        <h5>
                            {post.content}
                        </h5>
                        <small>Posted by :- {post.userName}</small>

                        <div class="post-comments-list mt-4">
                            <h6>Comments:</h6>
                            <ul>
                                {(props.post.commentsData).map((comment) => {
                                    // const postUser = findPostUser(post);
                                    return (
                                        <li>
                                            {/* <Comments comment={comment}></Comments> */}
                                            {comment}
                                            
                                        </li>

                                    )

                                })}
                            </ul>



                            {commentForm}
                            {/* <form onSubmit={createComment} class="row g-1">
                                <div class="col-auto">
                                    <input type="text" name="content" placeholder="Add Comment..." required class="form-control" value={content.content} onChange={handleChange} />
                                </div>
                                <div class="col-auto">
                                    <input type="submit" value="Go" class="btn btn-dark mb-3" />
                                </div>
                            </form> */}



                        </div>


                    </div>
                    <div className='  card-body'>
                        {temp}
                    </div>



                </div>
            </div>
        </div>

    )
}

export default Post;
