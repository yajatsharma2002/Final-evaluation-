import React, { useState, useContext } from 'react'
import { useNavigate } from "react-router-dom"
import userContext from '../context/users/userContext';

const Login = () => {

    const Navigate = useNavigate();
    const context = useContext(userContext);
    const { getUser } = context;

    const [credentials, setCredentials] = useState({ email: "", password: "" });

    const handleSubmit = async (e) => {
        e.preventDefault();
        // console.log(credentials);
        const response = await fetch("http://localhost:5000/users/login", {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: credentials.email, password: credentials.password })
        });
        const json = await response.json();
        //   console.log(json);
        if (json.data.token) {
            localStorage.setItem("token", json.data.token);
            getUser();
            Navigate("/");
        } else {
            Navigate("/")
        }
    }

    // const onChange = (e) => {
    //     setCredentials({ ...credentials, [e.target.name]: e.target.value })
    // }

    return (
        // <div>
        //     <h2>Login Here</h2>
        //     <form onSubmit={handleSubmit}>

        //         <div>
        //             <label>email</label>
        //             <input type="email" id="email" name="email" onChange={onChange} value={credentials.email}></input>
        //         </div>
        //         <div>
        //             <label>password</label>
        //             <input type="password" id="password" name="password" onChange={onChange} value={credentials.password}></input>
        //         </div>
        //         <button type="submit" >Submit</button>
        //     </form>
        // </div>



        <div className='container'>

            <h2>Login to Mediap</h2>

            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email </label>
                    <input type="email" className="form-control" id="email" aria-describedby="emailHelp" name="email" onChange={(e)=>{
                        setCredentials({...credentials,email:e.target.value})
                    }} value={credentials.email} />

                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input type="password" className="form-control" id="password" name="password" onChange={(e)=>{
                        setCredentials({...credentials,password:e.target.value})
                    }}  value={credentials.password}/>
                </div>

                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default Login
