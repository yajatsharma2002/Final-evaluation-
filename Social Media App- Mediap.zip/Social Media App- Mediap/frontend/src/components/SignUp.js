import React, { useState,useContext } from 'react'
import {useNavigate} from "react-router-dom"
import userContext from '../context/users/userContext';

const SignUp = () => {

    const Navigate=useNavigate();
    const context=useContext(userContext);
    const {getUser}=context;

    const [credentials,setCredentials]=useState({name:"",email:"",password:""});

    const handleSubmit=async (e)=>{
        e.preventDefault();

        // console.log(credentials.email);
        const response = await fetch("http://localhost:5000/users/register", {
            method: 'POST', 
            mode: 'cors', 
            cache: 'no-cache', 
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({email:credentials.email,password:credentials.password,name:credentials.name }) 
          });
          const json= await response.json();
        //   console.log(json.data.token);
          if(json.data.token){
            localStorage.setItem("token",json.data.token);
            getUser();
            Navigate("/");
          }else{
            Navigate("/signUp")
          }
    }

    const onChange=(e)=>{
        setCredentials({...credentials,[e.target.name]:e.target.value})
    }

    return (
        // <div>
        //     <h2>SignUp Here</h2>
        //     <form onSubmit={handleSubmit}>
        //         <div>
        //             <label>name</label>
        //             <input type="text" id="name" name="name" onChange={onChange} value={credentials.name}></input>
        //         </div>
        //         <div>
        //             <label>email</label>
        //             <input type="email" id="email" name="email" onChange={onChange} value={credentials.email}></input>
        //         </div>
        //         <div>
        //             <label>password</label>
        //             <input type="password" id="password" name="password" onChange={onChange} value={credentials.password}></input>
        //         </div>
        //         <button type="submit" >Submit</button>
        //     </form>
        // </div>
        <div className="container">
            <h2>Sign up to Mediap</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="name" className="form-label">Username </label>
                    <input type="text" className="form-control" id="name" name="name" aria-describedby="emailHelp" onChange={onChange} value={credentials.name} />
                </div>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email </label>
                    <input type="email" className="form-control" id="email"  name="email" aria-describedby="emailHelp" onChange={onChange} value={credentials.email}  />
                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input type="password" className="form-control" id="password" name="password" onChange={onChange} value={credentials.password} />
                </div>

                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default SignUp
