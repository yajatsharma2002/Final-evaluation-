import React, { useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import userContext from "../context/users/userContext"


const Createpost = () => {

    const Navigate = useNavigate();
    const context=useContext(userContext);
    const {addPost} = context;

    const [content, setContent] = useState({ content: "" });

    useEffect(() => {
        if (localStorage.getItem("token")) {

        }
        else {
            Navigate("/");
        }
    })

    const handleClick = async (e) => {
        e.preventDefault();

        addPost(content.content);

        setContent({content: "" });
    }

    const onChange = (e) => {
        setContent({ ...content,[ e.target.name]: e.target.value })
    }

    return (
        <div className="mb-3 w-50 mx-auto">
            <h4>Create a Post</h4>
            <form onSubmit={handleClick}>
                <textarea type="text" rows={3} className="form-control" id="name" name="content" aria-describedby="emailHelp" onChange={onChange} value={content.content} />
                {/* <textarea name="content" id="" cols="" rows="3" placeholder="Create your post" required className="form-control"></textarea> */}
                <button type="submit" className="mb-3 mt-3 form-control w-25 btn btn-dark">Post</button>
            </form>
        </div>
    )
}

export default Createpost
