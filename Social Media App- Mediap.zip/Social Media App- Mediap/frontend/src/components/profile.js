import React from 'react'
import { useLocation } from 'react-router-dom'

const Profile = () => {

    const location = useLocation();
    console.log(location.state.user.name);

    return (
        <div className='container'>
            {/* <img src="https://reactjs.org/logo-og.png" alt="React Image" /> */}
            <img src="https://cdn.pixabay.com/photo/2018/08/28/13/29/avatar-3637561_1280.png" height={400} width={300} style={{padding:23}}></img>

            <div class="card text-right" >
                {/* <!-- <div class="card-header">
                    <%= user.name %> Profile
                </div> --> */}
                <div class="card-body">
                    <h5 class="card-title">{location.state.user.name} Profile</h5>
                    <p class="card-text">Name: {location.state.user.name}</p>
                    <p class="card-text">Email: {location.state.user.email}</p>
                    {/* <!-- <a href="#" class="btn btn-primary">Go somewhere</a> --> */}
                </div>
                {/* <!-- <div class="card-footer text-muted">
                    2 days ago
                </div> --> */}
            </div>
        </div>
    )
}

export default Profile
