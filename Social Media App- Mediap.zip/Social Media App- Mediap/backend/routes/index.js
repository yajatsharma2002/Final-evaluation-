const express=require("express");
const router=express.Router();

const homeComtroller=require("../controllers/homeController");

router.get("/",homeComtroller.home);

router.use("/users",require("./users"));

router.use("/posts",require("./posts"));

router.use("/comments",require("./comment"));

module.exports=router;