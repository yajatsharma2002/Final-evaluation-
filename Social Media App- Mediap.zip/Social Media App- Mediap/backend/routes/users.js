
const express=require("express");
const router=express.Router();
const passport=require("passport");
const jwt=require("jsonwebtoken");
// const User=require("../models/User");

const userController=require("../controllers/userController");

router.post("/register",userController.register);
router.post("/login",userController.login);
router.get("/getUser",passport.authenticate("jwt",{session:false}),userController.getUser);
router.get("/getAllUsers",userController.getAllUsers);

module.exports=router;