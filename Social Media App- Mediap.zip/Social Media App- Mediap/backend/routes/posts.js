const express=require("express");
const router=express.Router();
const passport=require("passport");
const jwt=require("jsonwebtoken");

const postController=require("../controllers/postsController");

router.post("/create",passport.authenticate("jwt",{session:false}),postController.create)
router.get("/getAllPosts",postController.getAllPosts);
router.post("/delete/:id",passport.authenticate("jwt",{session:false}),postController.delete);


module.exports=router;