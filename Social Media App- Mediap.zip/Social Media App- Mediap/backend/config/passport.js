const passport=require("passport");
const JWTStrategy=require("passport-jwt").Strategy;
const ExtractJWT=require("passport-jwt").ExtractJwt;

const User=require("../models/User");

let opts={
    jwtFromRequest : ExtractJWT.fromAuthHeaderAsBearerToken(),
    secretOrKey :"mediap"
};

passport.use(new JWTStrategy(opts,async function(jwtPayload,done){

    try {
        const user=await User.findById(jwtPayload._id);
        if(user){
            return done(null,user);
        }
        else{
            return done(null,false);
        }
    } catch (error) {
        return console.log("error in finding the user from JWT");
    }



}))

module.exports = passport;
