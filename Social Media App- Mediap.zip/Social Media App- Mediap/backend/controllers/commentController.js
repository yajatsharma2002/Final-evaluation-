
const express=require("express");
const passport=require("passport");
const jwt=require("jsonwebtoken");
const User=require("../models/User");
const jwtSecret="mediap";
const Post =require("../models/Post");
const Comment=require("../models/Comment");

module.exports.create = async(req,res)=>{

    const {content,postId} = req.body;
    try {
        
        const post=await Post.findById(postId);
        if(post){
            const comment=await Comment.create({
                content:content,
                user:req.user.id,
                post:postId
            })
            post.comments.push(comment);
            post.commentsData.push(content);
            post.save();
            return res.send(post);
        }
        else{
            return res.send("post is not available");
        }


    } catch (error) {
        return res.send(error);
    }

}

module.exports.allComments = async(req,res)=>{
    const comments = await Comment.find();
    return res.send(comments);
}

module.exports.destroy=async function(req,res){

    try{

        let comment =await Comment.findById(req.params.id);
        // console.log(comment);
        if(comment){
            let data = comment.content;

        if(comment.user==req.user.id){
            const post_id=comment.post.toString();;
            // comment.remove();
            comment.deleteOne({id:req.params.id});

            let post=await Post.findByIdAndUpdate(post_id,{$pull:{comments:req.params.id}});

            let post2=await Post.findByIdAndUpdate(post_id,{$pull:{commentsData:data}});

            // console.log(post_id);
            // let post=await Post.findOne({id:post_id});
            // console.log(post);
            // var idx=-1;
            // for(var i=0;i<post.comments.length;i++){
            //     console.log(post.comments[i].toString());
            //     console.log(req.params.id);
            //     if(post.comments[i].toString() == req.params.id){
            //         console.log("found id success");
            //         idx=i;
            //         break;
            //     }
            // }
            // if(idx >=0){
            //     console.log("now deleting");
            //     (post.comments).splice(idx, 1);
            // }
            res.send("ids are matched succesfully");
            
        }
        }
        
        else{
            res.send("sorry");
        }

    }catch(err){
        console.log("error",err);
        return ;
    }

    
}