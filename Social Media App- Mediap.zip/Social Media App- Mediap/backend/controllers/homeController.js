
module.exports.home = (req,res)  =>{
    res.send("home Controller");
}