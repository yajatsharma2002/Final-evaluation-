
// module.exports.profile=(req,res)=>{
//     res.send('<h1>Users Profile</h1>')
// }

const express=require("express");
const passport=require("passport");
const jwt=require("jsonwebtoken");
const User=require("../models/User");
const jwtSecret="mediap";


// here we are creating a new user
module.exports.register=async(req,res)=>{
    // console.log("while registering");
    // console.log(req.body);
    const {email,password,name}=req.body;
    
    try {
        let user=await User.findOne({email:email});
        if(user){
            res.json("user existed previosly ");
            return;
        }

        user=await User.create({
            name:name,
            email:email,
            password:password
        });

        let data={
            _id:user._id
        }

        return res.send({
            message:"You are Syccesfully signed up",
            data:{
                token:jwt.sign(data,jwtSecret)
            }
        })



    } catch (error) {
        console.log(error, " error in creating a new user");
        return res.status(500).json({error:"Some error Occured"});
    }
}


// here we are loging in the user
module.exports.login=async(req,res)=>{
    const {email}=req.body;
    try {
        let user=await User.findOne({email:email});
        if(!user){
            return res.send("Sorry Invalid username or Password");
        }
        if(user.password != req.body.password){
            return res.send("Sorry Invalid username or Password");
        }

        let data={
            _id:user._id
        }

        return res.send({
            message:"You are Syccesfully logged in",
            data:{
                token:jwt.sign(data,jwtSecret)
            }
        })


    } catch (error) {
        console.log(error, " error in loggin in a new user");
        return res.status(500).json({error:"Some error Occured"});
    }
}

// getting the logged in user
module.exports.getUser=async(req,res)=>{
    try {
        const userId=req.user.id;
        const user=await User.findById(userId);
        res.json(user);
    } catch (error) {
        return res.status(500).send("internal server error");
    }
}

module.exports.getAllUsers = async(req,res)=>{
    try {
        const users=await User.find();
        return res.json(users);
    } catch (error) {
        return res.send("some error occured in fetching all the users")
    }
}