
const express=require("express");
const passport=require("passport");
const jwt=require("jsonwebtoken");
const User=require("../models/User");
const Post=require("../models/Post");
const jwtSecret="mediap";

const findUser=async(id)=>{
    const postUser=await User.findById(id);
    // console.log("printing post user"+postUser.name);
    return postUser.name;
}

// here we are creating a new post and user must be logged in 
module.exports.create= async(req,res)=>{
    
    const {content} = req.body;
    // console.log(content);
    // console.log(req.user.id);
    // return res.send("post");
    try {
        const postUser=await findUser(req.user.id);
        // console.log("postUser "+postUser);
        let post=await Post.create({
            content:content,
            user:req.user.id,
            userName:postUser
            // user:req.user.id
        })

        return res.send(post);

    } catch (error) {
        console.log(error);
        return res.json("Some error Occured");
    }
}

module.exports.getAllPosts=async(req,res)=>{
    const posts=await Post.find();
    res.send(posts);
}

module.exports.delete=async(req,res)=>{
    const {id}=req.body;
    // console.log(id);
    try {

    //     const posts=await Post.find();
    // res.send(posts);
        const post=await Post.findById(req.params.id);
        
        const another=post.user.toString();
        console.log(another);
        console.log(id);
        // console.log(req.body.id);
        console.log(req.params.id);
        if(req.user.id == another){
            // console.log("ids are matched");
            const result=await Post.findByIdAndDelete({_id:req.params.id});
            return res.send(result);
        }
        else{
            return res.json("invalid deletion");
        }


    } catch (error) {
        console.log(error);
        return res.json("some error occured while deleting the user");
    }
}