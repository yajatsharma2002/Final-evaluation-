const mongoose=require("mongoose");
const Comment = require("./Comment");
const User=require("./User")

const postSchema=new mongoose.Schema({
    content:{
        type:String,
        requires:true
    },
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:User
    },
    userName:{
        type:String
    },
    // include the array of ids of all the comments
   comments:[
    {
        type:mongoose.Schema.Types.ObjectId,
        ref:'Comment'
    }
   ],
   commentsData:[
    {
        type:String
    }
   ]


},{timestamps:true});


module.exports=mongoose.model("Post",postSchema);